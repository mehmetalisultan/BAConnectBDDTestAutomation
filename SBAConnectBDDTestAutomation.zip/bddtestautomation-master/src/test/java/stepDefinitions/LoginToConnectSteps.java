package stepDefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.ConnectLoginPages;

public class LoginToConnectSteps {

    private ConnectLoginPages loginPages;

    @Given("^user goes to SBA connect web$")
    public void user_goes_to_SBA_connect_web() throws Throwable {
        loginPages =new ConnectLoginPages();
        loginPages.gotURL();
    }

    @When("^user click for login for external user$")
    public void user_click_for_login_for_external_user() throws Throwable {
        loginPages.loginBtn();
    }

    @When("^user click the \"([^\"]*)\" btn on term&condt page$")
    public void user_click_the_btn_on_term_condt_page(String arg1) throws Throwable {
        loginPages.acceptBtn();
    }

    @When("^user enters valid email and password$")
        public void user_enters_valid_email_And_password () {
            loginPages.setEmail("connectsba009@gmail.com");
            loginPages.setPassword("UnutmaMexpey!@");
        }

        @And("^user click the \"([^\"]*)\"$")
        public void user_click_the (String signIn) throws Throwable {
            loginPages.signIn();
        }

      /* @And("^user enters the otp code and click \"([^\"]*)\"$")
        public void user_enters_the_otp_code_and_click (String otpCode) throws Throwable {
            loginPages.setSecurityCode("145b12679d9b");
            loginPages.submitOtp();
        }
        */

    @When("^user enters the otpCode and click Submit$")
    public void user_enters_the_otpCode_and_click_Submit() throws Throwable {
        loginPages.setSecurityCode("24de3eb13ead");
        loginPages.submitOtp();
    }
   /*
    @When("^user enters the <otp code> and click Submit$")
    public void user_enters_the_otp_code_and_click_Submit(DataTable arg1) throws Throwable {
        // For automatic transformation, change DataTable to one of
        // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
        // E,K,V must be a scalar (String, Integer, Date, enum etc)

    }
*/


    @Then("^user navigates to the home page$")
        public void user_navigates_to_the_home_page () {

        loginPages.setWelcomeSignHello();
        }
/*
    @Then("^user should navigate to term&condt page$")
    public void user_should_navigate_to_term_condt_page() throws Throwable {

    }
*/


    //view Update user profile
/*
    @Given("^user on sba connect home page$")
    public void user_on_sba_connect_home_page() throws Throwable {

    }

    @When("^user click view profile link$")
    public void user_click_view_profile_link() throws Throwable {
        loginPages.clickViewUpdateLink();
    }
    @When("^user should able to update \"([^\"]*)\"$")
    public void user_should_able_to_update(String name) throws Throwable {
        loginPages.fillName("Alex");
    }


    @When("^user should able to update firstName$")
    public void user_should_able_to_update_firstName() throws Throwable {
        loginPages.fillName("Alex");
    }

    @When("^user should able to update middleName$")
    public void user_should_able_to_update_middleName() throws Throwable {
        loginPages.fillName("M");
    }

    @When("^user should able to update lastName$")
    public void user_should_able_to_update_lastName() throws Throwable {
        loginPages.fillName("Roger");
    }

    @Then("^user click submit able to update profile$")
    public void user_click_submit_able_to_update_profile() throws Throwable {
        loginPages.clickSubmitBtn();
    }
    */

}
