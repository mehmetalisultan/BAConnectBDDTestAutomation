package stepDefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.openqa.selenium.By;
import pages.GoogleHomePage;

import static utility.UserAction.*;

public class DemoSteps {

    private GoogleHomePage googleHomePage;

    @Given("^user goes to google website$")
    public void user_goes_to_google_website() throws Throwable {
        googleHomePage= new GoogleHomePage();
        googleHomePage.gotSearch();
    }

    @When("^user searchs for apple$")
    public void user_searchs_for_apple() throws Throwable {
        googleHomePage.search("apple");
        int linkCount = driver().findElements(By.xpath("//a")).size();
    }

    @Then("^I should see a list of links$")
    public void i_should_see_a_list_of_links() throws Throwable {
        int linkCount = driver().findElements(By.xpath("//a")).size();
    }

    @Then("^I should see a no list of links$")
    public void i_should_see_a_no_list_of_links() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        int linkCount = driver().findElements(By.xpath("//a")).size();
        Assert.assertTrue(linkCount > 0);
    }
}
