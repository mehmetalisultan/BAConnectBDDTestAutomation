package stepDefinitions;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import utility.UserAction;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

public class Hooks {

    private static WebDriver driver;

    @Before
    public void beforeScenario() {
        selectPreferredBrowser();
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.HOURS);
        UserAction.initialize(driver);
    }


    @After
    public void afterScenario(Scenario scenario) {
        if(scenario.isFailed()) {
            byte[] screenshot;
            screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
            scenario.embed(screenshot, "image/png"); //Embed image in reports
        }

        if (driver != null) {
            driver.close();
            driver.quit();
        }
    }


    // Helper Method
    // allows user to select the preferred browser
    // User can select following browser options
    // choice={ chrome, headless chrome, firefox, edge }
    // with command line option -Dbrowser=choice
    private void selectPreferredBrowser() {
        String browser = System.getProperty("browser");
        System.out.println("Chosen Browser: " + browser);
        if(browser.equalsIgnoreCase("chrome") ) {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
        }
        else if(browser.equalsIgnoreCase("firefox")) {
            WebDriverManager.firefoxdriver().setup();
            driver = new FirefoxDriver();
        }
        else if(browser.equalsIgnoreCase("edge")) {
            WebDriverManager.edgedriver().setup();
            driver = new EdgeDriver();
        }
        else if(browser.equalsIgnoreCase("headless")) {
            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--headless", "--disable-gpu", "--window-size=1920,1200","--ignore-certificate-errors");
            driver = new ChromeDriver(options);
        }
        else {
            // if the user did not choose the preferred browser
            // the default browser is google chrome
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
        }
    }
}
