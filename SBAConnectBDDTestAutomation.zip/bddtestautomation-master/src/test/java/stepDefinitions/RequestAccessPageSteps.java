package stepDefinitions;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.ConnectLoginPages;

public class RequestAccessPageSteps {

   private ConnectLoginPages loginPages;

   @Given("^user on sba connect home page$")
    public void user_on_sba_connect_home_page() throws Throwable {

    }

    @When("^user click request access link$")
    public void user_click_request_access_link() throws Throwable {
        loginPages =new ConnectLoginPages();
        loginPages.clickrequestAccessLink();
    }


    @When("^user click EDMIS web$")
    public void user_click_EDMIS_web() throws Throwable {
        loginPages.clickEDMISCard();
    }

    @When("^user select Resource Partner View checkbox$")
    public void user_select_Resource_Partner_View_checkbox() throws Throwable {
        loginPages.clickResourcePartnerUpdate();
    }


    @When("^user click WBC radio button$")
    public void user_click_WBC_radio_button() throws Throwable {
        loginPages.clickWBCRadioBtn();
    }



    @When("^user enter EIN$")
    public void user_enter_EIN() throws Throwable {
        loginPages.setEnterEIN("967259946");
    }

    @When("^user click SUBMIT REQUEST button$")
    public void user_click_SUBMIT_REQUEST_button() throws Throwable {
        loginPages.clickSubmitRequest();
    }

    @When("^user click OK button$")
    public void user_click_OK_button() throws Throwable {
        loginPages.clickOK();
    }


    @When("^user click sbic web and select sbic agent$")
    public void user_click_sbic_web_and_select_sbic_agent() throws Throwable {
        loginPages.clickSBICCard();
    }

    @When("^user enter the ein number$")
    public void user_enter_the_ein_number() throws Throwable {
        //loginPages.
    }

    @When("^user click submit$")
    public void user_click_submit() throws Throwable {

    }

    @When("^user click ok$")
    public void user_click_ok() throws Throwable {

    }

    @Then("^user navigate back to request access page$")
    public void user_navigate_back_to_request_access_page() throws Throwable {
    loginPages.clickOK();
    }

}
