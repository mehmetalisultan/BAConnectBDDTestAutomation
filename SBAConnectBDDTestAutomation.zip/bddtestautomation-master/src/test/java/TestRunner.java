import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)  // JUnit
@CucumberOptions(         // Cucumber-Junit
        features = {"features/"},
        glue = {"stepDefinitions"},
        plugin = {"json:report/json/cucumber.json"},
        monochrome = true  // console output is readable format
)
public class TestRunner {
}
