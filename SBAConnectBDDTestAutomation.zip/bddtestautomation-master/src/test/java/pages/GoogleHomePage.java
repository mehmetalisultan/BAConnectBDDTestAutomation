package pages;
import org.openqa.selenium.By;

import static utility.UserAction.*;
public class GoogleHomePage {
    //private final String url = "https://www.google.com";

    // page elements
    private final By searchInput = By.name("q");
    private final By searchButton = By.cssSelector(".FPdoLc [value='Google Search']");

    //page actions

   public void gotSearch() {
       String url = System.getProperty("URL");
       open(url);
   }
   public void search(String input){
       typeInto(searchInput, input);
       click(searchButton);
   }

}
