/*
package pages;
import org.openqa.selenium.By;
import static utility.UserAction.*;



    //links
    private final By accessManagerLink = By.xpath("//a[@href='/Access/AccessGrant']");
    private final By requestAccessLink = By.xpath("//a[@href='/RequestAccess']");
    private final By viewProfileLink = By.xpath("//a[@href='/Profile/EditOrViewProfile']");
    private final By logOutLink = By.xpath("//a[@href='/Account/SignOut']");
    private final By helpDropdown = By.xpath("//div[@id='desktop-nav']/ul//a[@href='#']");
    private final By contactUs = By.xpath("//a[@href='/Home/ContactUs']");
    private final By userManual = By.xpath("//a[@href='/Home/GetSBAConnectUserManual']");
    private final By helpFAQ = By.xpath("//a[@href='/Home/FAQS']");

    //logo
    private final By connectLink = By.xpath("//*[@id=\"connect-name\"]");
    private final By connectLogo = By.xpath("//img[@alt='SBA Logo ']");
    //a[@href='/Dashboard/Landing']/img[@alt='SBA Logo ']

    //request access links & button
    private final By requestAccessbtn = By.xpath("//input[@id='NoRoles']");
    private final By requestAccessLink = By.xpath("//a[@href='/RequestAccess']");
    private final By requestSBIC = By.xpath("//*[text()='SBIC Web – Small Business Investment Company']");
    private final By connectLogo = By.xpath("//img[@alt='SBA Logo ']");
    private final By connectLogo = By.xpath("//img[@alt='SBA Logo ']");
    private final By connectLogo = By.xpath("//img[@alt='SBA Logo ']");
    private final By connectLogo = By.xpath("//img[@alt='SBA Logo ']");
    private final By connectLogo = By.xpath("//img[@alt='SBA Logo ']");

    //applicatons: SBIC Web
    private final By linkSBIC = By.xpath("//*[@id=\"generic-card1\"]");
    //a[@href='/Dashboard/LandingDetail?AppId=310&EIN=0']

    //applicatons: PPP
    private final By linkPPP = By.xpath("//a[@href='/Dashboard/LandingDetail?AppId=336&EIN=0']");
   //  /html/body/div[1]/div/div[2]/div/div[3]/div[2]/div[7]/div/div/div/div/div/h5/i
   // /html//div[@class='col-md-10']/div[@class='ng-scope']/div[3]/div[2]/div[7]/div[@class='ng-scope']/div/div//h5[@role='button']/i[@class='fa fa-plus']


   //View/Update profile page elements

   private final By firstNameBtn = By.xpath("//input[@id='FirstName']")
   private final By middleNameBtn = By.xpath("//input[@id='MiddleName']")
   private final By lastNameBtn = By.xpath("//input[@id='LastName']")

   private final By suffixBtn = By.xpath("//input[@id='Suffix']")

   private final By firstNameBtn = By.xpath("//input[@id='MiddleName']")
   private final By firstNameBtn = By.xpath("//input[@id='MiddleName']")
   private final By firstNameBtn = By.xpath("//input[@id='MiddleName']")
   private final By firstNameBtn = By.xpath("//input[@id='MiddleName']")
   private final By firstNameBtn = By.xpath("//input[@id='MiddleName']")
   private final By firstNameBtn = By.xpath("//input[@id='MiddleName']")

   private final By continueBtn = By.xpath("//input[@name='Continue']")





}
*/
