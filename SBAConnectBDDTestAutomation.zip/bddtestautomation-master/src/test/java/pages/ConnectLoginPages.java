package pages;
import org.openqa.selenium.By;

import static utility.UserAction.*;
import static utility.UserAction.typeInto;

public class ConnectLoginPages {

    // Login pages elements
    /*private final By searchInput = By.name("q");
    private final By searchButton = By.cssSelector(".FPdoLc [value='Google Search']");
*/
    private final By loginBtnExternal = By.xpath("//a[@href='/Home/LoginExternal']");
    private final By createExtAccount = By.xpath("//a[@href='/Home/CreateExternal']");
    private final By loginBtnInternal = By.xpath("//a[@href='/Home/LoginInternal']");


    //term&Condition Page elements
    private final By acceptTerm = By.xpath("//input[@value='ACCEPT']");
    private final By declineBtn = By.xpath("//input[@value='DECLINE']");


    //creadential Page

    private final By useEmail = By.xpath("//input[@id='user_email']");
    private final By userPass = By.xpath("//input[@id='user_password']");
    private final By signInBtn = By.xpath("//input[@name='commit']");
    private final By createAccount = By.xpath("//form[@id='new_user']");

    //backUp code
    private final By securityCode = By.xpath("//*[@id='backup_code_verification_form_backup_code']");
    private final By submitSecurityCode = By.xpath("//*[@name='commit']");
    ////input[@name='commit']

    //otp code
    private final By otpCode = By.xpath("//input[@id='code']");
    private final By submitOtpBtn = By.xpath("//*[@name='commit']");

    // signIn after verify the otp code
    private final By signInWithotp = By.xpath("// input[@value='Sign in']");
    private final By swichEmails = By.xpath("//input[@value='Switch emails']");

    //home page
    private final By requestAccessBtn = By.xpath("//*[@id='NoRoles']");
    private final By welcomeSignHello = By.xpath("//*[contains(text(),'Hello ')]");

    //*******Request Access Page elements  *********//
    private final By requestAccessLink = By.xpath("//*[contains(text(),'Request Access')] ");
    private final By clickOK = By.xpath("//*[contains(text(),'OK')]");

    //********SBIC Web elemets******//

    private final By SBICCard = By.xpath("//*[contains(text(),'SBIC Web')]");

    //EDMIS elements  //*[contains(text(),'(EDMIS)')]
    private final By EDMISCard = By.xpath("//*[contains(text(),'(EDMIS)')]");
    private final By ResourcePartnerView = By.xpath("//*[@id=\"pagebody\"]/div/div[3]/div[1]/div[4]/div/div/div/div/div/div/div[2]/div/div/div[1]/div/md-checkbox/div[1]/div[1]");
    //private final By ResourcePartnerView = By.xpath("//*[contains(text(),'Resource Partner View')]");
    private final By ResourcePartnerUpdate = By.xpath("//*[contains(text(),'Resource Partner Update')]");
    private final By SBDCRadioBtn = By.xpath("//*[@id='radio_0']");
    private final By WBCRadioBtn = By.xpath("//*[@id='radio_0']");
    private final By SCORERadioBtn = By.xpath("//*[@id='radio_0']");
    private final By enterEIN = By.xpath("//*[@id='dunsNumber0']");
    private final By submitRequest = By.xpath("//*[@id=\"pagebody\"]/div/div[3]/center/button[1]");
    //*[@id="pagebody"]/div/div[3]/center/button[1]
    //*[contains(text(),'SUBMIT REQUEST']
    //private final By enterEIN = By.xpath("//*[@id='dunsNumber0']");


    //*******View/Update profile page elements******//

    private final By requestAccessbtn = By.xpath("//input[@id='NoRoles']");
    private final By firstNameBtn = By.xpath("//input[@id='FirstName']");
    private final By middleNameBtn = By.xpath("//input[@id='MiddleName']");
    private final By lastNameBtn = By.xpath("//input[@id='LastName']");
    //private final By viewProfileLink = By.xpath("//*[@id='sub-menu-1-title']");
    private final By viewProfileLink = By.cssSelector("#sub-menu-1-title");

    //a[@href='/Profile/EditOrViewProfile'] //*[@id="sub-menu-1-title"]
    private final By suffixBtn = By.xpath("//input[@id='Suffix']");
    private final By submitProfileBtn = By.xpath("//input[@name='Submit']");
    private final By continueBtn = By.xpath("//input[@name='Continue']");


    /*******Login Page actions  *********/

    public void gotURL() {
        String url = System.getProperty("URL");
        open(url);
    }

    public void createExtAccountBtn() {
        click(createExtAccount);

    }

    public void loginBtn() {
        click(loginBtnExternal);

    }

    public void acceptBtn() {
        click(acceptTerm);

    }

    public void declineBtn() {
        click(declineBtn);

    }

    public void setEmail(String email) {
        typeInto(useEmail, email);

    }

    public void setPassword(String password) {
        typeInto(userPass, password);

    }


    public void setOtpCode(String code) {
        typeInto(otpCode, code);

    }

    public void setSecurityCode(String code) {
        typeInto(securityCode, code);

    }

    public void submitOtp() {
        click(submitOtpBtn);

    }

    public void setWelcomeSignHello() {
        isPresent(welcomeSignHello);

    }
   /* public void submitBtn() {
        click(submitSecurityCode);

    }*/


    public void signIn() {
        click(signInBtn);

    }

    public void createAccount() {
        click(createAccount);

    }
   /* public void search(String input) {
        typeInto(searchInput, input);
        click(searchButton);

    }*/

    //View/Update action

    public void clickViewUpdateLink() {
        click(viewProfileLink);

    }



    public void clickRequestAccessBtn() {
        click(requestAccessBtn);

    }

    public void fillName(String name) {
        typeInto(firstNameBtn, name);

    }

    public void clickSubmitBtn() {
        click(submitProfileBtn);

    }

    public void clickContinueBtn() {
        click(continueBtn);

    }


    /*******Request Access Page actions  *********/


    public void clickrequestAccessLink() {
        click(requestAccessLink);
    }

    public void clickSBICCard(){
        click(SBICCard);

    }
    public void clickEDMISCard(){
        click(EDMISCard);

    }

    public void clickResourcePartnerUpdate() {
        click(ResourcePartnerUpdate);
    }

    public void clickResourcePartnerView() {
        click(ResourcePartnerView);
    }


    public void clickSBDCRadioBtn() {
        click(SBDCRadioBtn);
    }

    public void clickWBCRadioBtn() {
        click(WBCRadioBtn);
    }

    public void clickSCORERadioBtn() {
        click(SCORERadioBtn);
    }


    public void setEnterEIN(String ein) {
        typeInto(enterEIN, ein);

    }
  /*  public void TextBoxPartnerUpdate(String name) {
        typeInto(TextBoxPartnerUpdate, name);
    }*/

    public void clickSubmitRequest() {
        click(submitRequest);

    }


    public void clickOK() {
        click(clickOK);

    }


}