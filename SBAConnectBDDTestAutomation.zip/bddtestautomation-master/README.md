# Execution Triggers 
Executing specific tests 
```
gradle clean test -Dcucumber.options="--tags @smoke"
```
<br/>

If you want to trigger more than one tests 
just add desired cucumber tags with seperated with space 
```
gradle clean test -Dcucumber.options="--tags @smoke @regression @systeme2e"
```
<br/>

If you want to trigger test(s) with preferred browser 
you can do so with specifying the browser type 
```
gradle clean test -Dcucumber.options="--tags @smoke" -Dbrowser=chrome
```

|Browser         |Option String                  |
|----------------|-------------------------------|
|Chrome Headless |`-Dbrowser=headless`           |
|Google Chrome   |`-Dbrowser=chrome`             |
|Mozilla Firefox |`-Dbrowser=firefox`            | 
|Microsoft Edge  |`-Dbrowser=edge`               |  

